function eaTms() {
    var _this = this;

    this.server_referrer = 'https://account.e.jimdo.com/de/accounts/login';

    this.criteria_js_referrer = 'em_source';
    this.subid_js_referrer = 'em_campaign';
    this.publisher_js_referrer = '';
    this.admedia_js_referrer = '';


    this.criteria_server_referrer = '';
    this.subid_server_referrer = '';
    this.publisher_server_referrer = '';
    this.admedia_server_referrer = '';

    this.session_id = '5cbf82930d0c7857700eacce';

    this.rpc_url = '';
    if (this.rpc_url == '')
        this.rpc_url = '//pvn.jimdo.com/trck/etms/rpc.json';

    this.triplet = '';
    this.triplet_cache = { };
    this.click_url = 'https://pvn.jimdo.com/trck/eclick/{$triplet}?noredir=js';

    this.anychannel_id = '1001';
    this.seo_id = '-1';
    this.is_seo = false;
    this.campaign_id = '1';

    this.touchpoint_url = '';
    this.conversiontracking_url = 'https://pvn.jimdo.com/trck/etrack/?campaign_id=1&trigger_id=1&token={$token}&descr=sale&container_params={$ref}&t=js';

    this.basketFreeze = localStorage.getItem('eamTrck_BasketFreeze');
    this.localTime = parseInt(new Date() / 1000);

    

    this.init = function () {
        this.referrer = document.referrer;
        this.href = window.location.href;
        this.referrer_get = this.getParams(this.referrer);
        this.server_referrer_get = this.getParams(this.server_referrer);
        this.href_get = this.getParams(this.href);

        if (typeof(sessionStorage) !== 'undefined' && sessionStorage.s_eamSessionId && sessionStorage.s_eamSessionId.length == 24) {
            this.session_id = sessionStorage.s_eamSessionId;
        } else if (typeof localStorage !== 'undefined' && localStorage.getItem('ls_eamSessionId') && localStorage.getItem('ls_eamSessionId').length == 24) {
            this.session_id = localStorage.getItem('ls_eamSessionId');
        }

        if (typeof sessionStorage !== 'undefined') {
            sessionStorage.s_eamSessionId = this.session_id;
        }

        if (typeof localStorage !== 'undefined') {
            localStorage.setItem('ls_eamSessionId', this.session_id);
        }
    };

    this.getCookie = function (cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    };

    this.insertAndExecute = function (id, text) {
        domelement = document.getElementById(id);
        domelement.innerHTML = text;
        var scripts = [];

        ret = domelement.childNodes;
        for (var i = 0; ret[i]; i++) {
            if (scripts && _this.nodeName(ret[i], "script") && (!ret[i].type || ret[i].type.toLowerCase() === "text/javascript")) {
                scripts.push(ret[i].parentNode ? ret[i].parentNode.removeChild(ret[i]) : ret[i]);
            }
        }

        for (script in scripts) {
            _this.evalScript(scripts[script]);
        }
    }

    this.nodeName = function (elem, name) {
        return elem.nodeName && elem.nodeName.toUpperCase() === name.toUpperCase();
    }

    this.evalScript = function (elem) {
        data = ( elem.text || elem.textContent || elem.innerHTML || "" );

        var head = document.getElementsByTagName("head")[0] || document.documentElement,
            script = document.createElement("script");
        script.type = "text/javascript";
        script.appendChild(document.createTextNode(data));
        head.insertBefore(script, head.firstChild);
        head.removeChild(script);

        if (elem.parentNode) {
            elem.parentNode.removeChild(elem);
        }
    }

    this.getParams = function (addr) {
        var params = new Array();
        if (addr.indexOf('?') !== -1) {
            addr = addr.split('?')[1].split('&');
            for (var i = 0; i < addr.length; i++) {
                var item = addr[i].split('=');
                if (item[0])
                    params[item[0]] = (item[1]) ? item[1] : "";
            }
        } else if (addr.indexOf('#') !== -1) {
            addr = addr.split('#')[1].split('&');
            for (var i = 0; i < addr.length; i++) {
                var item = addr[i].split('=');
                if (item[0])
                    params[item[0]] = (item[1]) ? item[1] : "";
            }
        }
        return params;
    };

    this.runByJsReferrer = function () {
        if (typeof this.href_get[this.criteria_js_referrer] !== 'undefined') {
            this.tripletCriteria = this.href_get[this.criteria_js_referrer];
        } else {
            return false;
        }

        if (typeof this.referrer_get[this.subid_js_referrer] !== 'undefined') {
            this.subid = this.referrer_get[this.subid_js_referrer];
        } else if (typeof this.href_get[this.subid_js_referrer] !== 'undefined') {
            this.subid = this.href_get[this.subid_js_referrer];
        }

        if (typeof this.referrer_get[this.publisher_js_referrer] !== 'undefined') {
            this.publisher = this.referrer_get[this.publisher_js_referrer];
        } else if (typeof this.href_get[this.publisher_js_referrer] !== 'undefined') {
            this.publisher = this.href_get[this.publisher_js_referrer];
        }
        
        if (typeof this.referrer_get[this.admedia_js_referrer] !== 'undefined') {
            this.admedia = this.referrer_get[this.admedia_js_referrer];
        } else if (typeof this.href_get[this.admedia_js_referrer] !== 'undefined') {
            this.admedia = this.href_get[this.admedia_js_referrer];
        }
        
        return true;
    };

    this.runByServerReferrer = function () {
        if (typeof this.server_referrer_get[this.criteria_server_referrer] !== 'undefined') {
            this.tripletCriteria = this.server_referrer_get[this.criteria_server_referrer];
        } else {
            return false;
        }

        if (typeof this.server_referrer_get[this.subid_server_referrer] !== 'undefined') {
            this.subid = this.server_referrer_get[this.subid_server_referrer];
        }

        if (typeof this.server_referrer_get[this.publisher_server_referrer] !== 'undefined') {
            this.publisher = this.server_referrer_get[this.publisher_server_referrer];
        }

        if (typeof this.server_referrer_get[this.admedia_server_referrer] !== 'undefined') {
            this.admedia = this.server_referrer_get[this.admedia_server_referrer];
        }
        
        return true;
    };

    this.registerClick = function (triplet, replaceQuestionmark) {
        if (this.click_url != '') {
            this.click_url = this.click_url.replace('{$triplet}', triplet);
            this.click_url = this.click_url.replace('{$ref}', encodeURIComponent(this.referrer));
            this.click_url = this.click_url.replace('{$session_id}', this.session_id);

            if(typeof this.subid !== 'undefined') {
                var subid_url = '&subid=' + this.subid;
            } else {
                var subid_url = '';
            }

            if(typeof this.publisher !== 'undefined') {
                var publisher_url = '&publisher=' + this.publisher;
            } else {
                var publisher_url = '';
            }

            if(typeof this.admedia !== 'undefined') {
                var admedia_url = '&admedia=' + this.admedia;
            } else {
                var admedia_url = '';
            }

            if (typeof replaceQuestionmark !== 'undefined' && replaceQuestionmark == true) {
                var nth = 0;
                var url = this.click_url.replace(/\?/g, function (match, i, original) {
                    nth++;
                    return (nth === 2) ? "&" : match;
                });
                this.getScript(url + subid_url + publisher_url + admedia_url);
            } else {
                this.getScript(this.click_url +  subid_url + publisher_url + admedia_url);
            }
        }
    }

    this.registerTouchpoint = function () {
        if (this.touchpoint_url != '') {
            this.touchpoint_url = this.touchpoint_url.replace('{$referrer}', encodeURIComponent(this.referrer));
            this.touchpoint_url = this.touchpoint_url.replace('{$session_id}', this.session_id);
            this.getScript(this.touchpoint_url);
        }
    }

    this.getScript = function (source, callback) {
        var script = document.createElement('script');
        var prior = document.getElementsByTagName('script')[0];
        script.async = 1;
        prior.parentNode.insertBefore(script, prior);

        script.onload = script.onreadystatechange = function (_, isAbort) {
            if (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) {
                script.onload = script.onreadystatechange = null;
                script = undefined;

                if (!isAbort) {
                    if (callback) callback();
                }
            }
        };

        script.src = source;
    }

    this.serialize = function (obj, prefix) {
        var str = [];
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                var k = prefix ? prefix + "[" + p + "]" : p, v = obj[p];
                str.push(typeof v == "object" ?
                    this.serialize(v, k) :
                encodeURIComponent(k) + "=" + encodeURIComponent(v));
            }
        }
        return str.join("&");
    }

    this.getJSON = function (path, data, success, error) {
        var xhr = new XMLHttpRequest();
        path = path + '?' + this.serialize(data);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    if (success)
                        success(JSON.parse(xhr.responseText));
                } else {
                    if (error)
                        error(xhr);
                }
            }
        };
        xhr.open("GET", path, true);
        xhr.send();
    }

    this.getTriplet = function () {
        if (typeof this.tripletCriteria !== 'undefined') {
            var cache_criteria = this.tripletCriteria.trim().replace(' ', '');
            if (typeof this.triplet_cache[cache_criteria] != 'undefined') {
                this.registerClick(this.triplet_cache[cache_criteria]);
            } else {
                this.getJSON(
                    this.rpc_url,
                    {
                        function: 'getTriplet',
                        data: {
                            triplet: this.tripletCriteria
                        }
                    },
                    function (data) {
                        eaTms.registerClick(data.triplet);
                    }
                );
            }
        } else if (this.getCookie('trs') != '') {
            this.registerTouchpoint();
        }
    };

    this.runTracking = function () {
        if (this.conversiontracking_url != '') {
            var params = this.getParams(window.location.href);
            if (typeof basketOrderUUID != 'undefined' && basketOrderUUID != 'undefined' && basketOrderUUID != '') {
                this.conversiontracking_url = this.conversiontracking_url.replace('{$token}', basketOrderUUID);
                this.conversiontracking_url = this.conversiontracking_url.replace('{$ref}', encodeURIComponent(window.location.href));
                this.getScript(this.conversiontracking_url);
            } else if (typeof params['pagetype'] != 'undefined' && params['pagetype'] == 'checkout_step_thanks' && params['OrderID'] != '') {
                this.conversiontracking_url = this.conversiontracking_url.replace('{$token}', params['OrderID']);
                this.conversiontracking_url = this.conversiontracking_url.replace('{$ref}', encodeURIComponent(window.location.href));
                this.getScript(this.conversiontracking_url);
            } else if (typeof params['OrderID'] != 'undefined' && params['OrderID'] != '') {
                var source = $('head').html();
                var token = source.slice(source.search('basketOrderUUID'), source.indexOf(';', source.search('basketOrderUUID'))).split('="')[1].replace('"', '').trim();
                this.conversiontracking_url = this.conversiontracking_url.replace('{$token}', token);
                this.conversiontracking_url = this.conversiontracking_url.replace('{$ref}', encodeURIComponent(window.location.href));
                this.getScript(this.conversiontracking_url);
            }
        }
    };

    this.registerTrackingByReferrer = function (referrer) {
        this.getJSON(
            this.rpc_url,
            {
                function: 'getTripletByReferrer',
                data: {
                    referrer: referrer
                }
            },
            function (data) {
                eaTms.registerClick(data.triplet);
            }
        );
    };

    this.isSearchReferrer = function(referrer) {
        return referrer.match(/^(https|http):\/\/www\.google\.(de|com|fr|co\.uk|nl|ch|at|cz|pl)/g) 
            || referrer.match(/^(http|https):\/\/www\.bing\.com/g);
    };

    this.runByDirectTypeIn = function () {
        eaTms.registerClick('?campaign_id=' + this.campaign_id + '&project_id=' + this.anychannel_id + '&admedia_alias=default&clicktype=first_click&noredir=js&timestamp=' + Date.now() + '&subid=' + encodeURIComponent(this.referrer), true);
    };

    this.runBySEO = function() {
        if(this.seo_id > 0 && this.isSearchReferrer(this.referrer)) {
            this.is_seo = true;
            eaTms.registerClick('?campaign_id=' + this.campaign_id + '&project_id=' + this.seo_id + '&admedia_alias=default&clicktype=seo_click&noredir=js&timestamp=' + Date.now() + '&subid=' + encodeURIComponent(this.referrer), true);
        } 
    };


    this.run = function () {
        if(typeof this.basketFreeze == null || this.localTime > this.basketFreeze) {
            if (this.criteria_js_referrer != '') {
                if (this.runByJsReferrer() == false) {
                    this.runBySEO();
                    if(this.session_id == '')
                        this.runByDirectTypeIn();
                }
            }

            if (this.criteria_server_referrer != '') {
                if (this.runByServerReferrer() == false) {
                    this.runBySEO();
                    if(this.session_id == '')
                        this.runByDirectTypeIn();
                }
            }

            this.triplet = this.getTriplet();
            this.runTracking();
        }
    };
}

function eaConvSys() {
    this.etrack_url = '//pvn.jimdo.com/trck/etrack/';
    this.init = function () {

    };

    this.serializeObj = function (obj) {
        var str = '';
        for (var key in obj) {
            if (str != "") {
                str += "&";
            }
            str += key + "=" + encodeURIComponent(obj[key]);
        }
        return str;
    };

    this.addConversion = function (data) {
        var url = this.etrack_url + '?' + this.serializeObj(data);
        console.log('Start ' + url);

        eaTms.getScript(url, function () {
            console.log('Done ' + url);
        });
    };
}


if (typeof eaTms == 'function') {
    var eaTms = new eaTms();
    eaTms.init();
    eaTms.run();
}

if (typeof eaConvSys == 'function') {
    var eaConvSys = new eaConvSys();
    eaConvSys.init();
}

(function() {
    var getKey = 'emid'
    var storageKey = 'emid'
    var getValue = getParameterByName(getKey)
    if(getValue) {
        window.localStorage.setItem(storageKey, getValue)
    }
    function getParameterByName(e,n){n||(n=window.location.href),e=e.replace(/[\[\]]/g,"\\$&");var r=new RegExp("[?&]"+e+"(=([^&#]*)|&|#|$)").exec(n);return r?r[2]?decodeURIComponent(r[2].replace(/\+/g," ")):"":null}
})();var eaTmsDocumentBodyReady = typeof document.getElementsByTagName('body')[0] != 'undefined';!function(){var e=window.DomReady={},t=navigator.userAgent.toLowerCase(),o={version:(t.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/)||[])[1],safari:/webkit/.test(t),opera:/opera/.test(t),msie:/msie/.test(t)&&!/opera/.test(t),mozilla:/mozilla/.test(t)&&!/(compatible|webkit)/.test(t)},n=!1,i=!1,a=[];function d(){if(!i&&(i=!0,a)){for(var e=0;e<a.length;e++)a[e].call(window,[]);a=[]}}function l(){if(!n){var e,t,a;if(n=!0,document.addEventListener&&!o.opera&&document.addEventListener("DOMContentLoaded",d,!1),o.msie&&window==top&&function(){if(!i){try{document.documentElement.doScroll("left")}catch(e){return void setTimeout(arguments.callee,0)}d()}}(),o.opera&&document.addEventListener("DOMContentLoaded",function(){if(!i){for(var e=0;e<document.styleSheets.length;e++)if(document.styleSheets[e].disabled)return void setTimeout(arguments.callee,0);d()}},!1),o.safari)!function(){if(!i)if("loaded"==document.readyState||"complete"==document.readyState){if(void 0===e){for(var t=document.getElementsByTagName("link"),o=0;o<t.length;o++)"stylesheet"==t[o].getAttribute("rel")&&e++;var n=document.getElementsByTagName("style");e+=n.length}document.styleSheets.length==e?d():setTimeout(arguments.callee,0)}else setTimeout(arguments.callee,0)}();t=d,a=window.onload,"function"!=typeof window.onload?window.onload=t:window.onload=function(){a&&a(),t()}}}e.ready=function(e,t){l(),i?e.call(window,[]):a.push(function(){return e.call(window,[])})},l()}();

function eaTmsLib() {
    var _this = this;
    this.insertAndExecute = function (id, text) {
        domelement = document.getElementById(id);
        domelement.innerHTML = text;

        var scripts = [];
        ret = domelement.childNodes;

        var ret = Array.prototype.slice.call(ret);

        for (var i = 0; i < ret.length; i++) {
            if (scripts && _this.nodeName(ret[i], "script")) {
                var src = '';
                if (typeof ret[i].src != 'undefined') {
                    var src = ret[i].src;
                }
                var javascript = ret[i].parentNode ? ret[i].parentNode.removeChild(ret[i]) : ret[i];
                scripts.push({src: src, javascript: javascript});

            }
        }

        for (script in scripts) {
            _this.evalScript(scripts[script]);
        }
    }

    this.nodeName = function (elem, name) {
        return elem.nodeName && elem.nodeName.toUpperCase() === name.toUpperCase();
    }

    this.evalScript = function (domelem) {
        var elem = domelem.javascript;
        if (typeof elem == 'undefined') {
            return false;
        }

        data = ( elem.text || elem.textContent || elem.innerHTML || "" );

        var head = document.getElementsByTagName("head")[0] || document.documentElement,
            script = document.createElement("script");
        script.type = "text/javascript";

        script.appendChild(document.createTextNode(data));
        if (domelem.src != '') {
            script.src = domelem.src;
        }
        head.insertBefore(script, head.firstChild);
        head.removeChild(script);

        if (elem.parentNode) {
            elem.parentNode.removeChild(elem);
        }
    }
}

var eaTmsStore = {
    localStoreSupport: function () {
        try {
            return 'localStorage' in window && window['localStorage'] !== null;
        } catch (e) {
            return false;
        }
    },
    set: function (name, value, days) {
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            var expires = "; expires=" + date.toGMTString();
        }
        else {
            var expires = "";
        }
        if (this.localStoreSupport()) {
            localStorage.setItem(name, value);
        }
        else {
            document.cookie = name + "=" + value + expires + "; path=/";
        }
    },
    get: function (name) {
        if (this.localStoreSupport()) {
            ret = localStorage.getItem(name);
            //console.log(typeof ret);
            switch (ret) {
                case 'true':
                    return true;
                case 'false':
                    return false;
                default:
                    return ret;
            }
        }
        else {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) {
                    ret = c.substring(nameEQ.length, c.length);
                    switch (ret) {
                        case 'true':
                            return true;
                        case 'false':
                            return false;
                        default:
                            return ret;
                    }
                }
            }
            return null;
        }
    },
    del: function (name) {
        if (this.localStoreSupport()) {
            localStorage.removeItem(name);
        }
        else {
            this.set(name, "", -1);
        }
    }
}

if (typeof eaTmsLib != 'object')
    var eaTmsLib = new eaTmsLib();

var eaTmsTagFunction5d2f6e5449c81 = function() {
	try {		var eaTrckElement5d2f6e5449c81 = document.createElement('div');
		eaTrckElement5d2f6e5449c81.setAttribute('id', 'eaTrckElement5d2f6e5449c81');
		document.getElementsByTagName('body')[0].appendChild(eaTrckElement5d2f6e5449c81);
		eaTmsLib.insertAndExecute('eaTrckElement5d2f6e5449c81', '<!-- START_JS 2 --> <script>    (function() {        var params = [];        var url = window.location.href;        if (url.indexOf(\'#\') !== -1) {            var addr = url.split(\'#\')[1].split(\'&\');            for (var i = 0; i < addr.length; i++) {                var item = addr[i].split(\'=\');                if (item[0])                    params[item[0]] = (item[1]) ? item[1] : "";            }        } else if (url.indexOf(\'?\') !== -1) {            var addr = url.split(\'?\')[1].split(\'&\');            for (var i = 0; i < addr.length; i++) {                var item = addr[i].split(\'=\');                if (item[0])                    params[item[0]] = (item[1]) ? item[1] : "";            }        }        if(typeof params.ref != \'undefined\') {            var project_id = params.ref.replace(\'a\', \'\');            var click_url = \'https://pvn.jimdo.com/trck/eclick/?campaign_id=1&project_id=\' + project_id + \'&admedia_id=390657&noredir=js\';            eaTms.getScript(click_url);        }    })();</script> <!-- END_JS 2 --> ');
	} catch(err) {			}};if(eaTmsDocumentBodyReady == true) { eaTmsTagFunction5d2f6e5449c81(); } else { DomReady.ready(eaTmsTagFunction5d2f6e5449c81); }