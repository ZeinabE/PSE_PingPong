(function (w){w._bb=w._bb||[];w._bb.push(["async attributes",{"geo":{"ip":"84.151.176.88","city":"Berlin","countryCode":"DE"}}]);})(window);
