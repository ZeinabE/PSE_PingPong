//Auswahl an Farben, die später geändert werden können 
var colorColl = ["WHITE","#ff0033", "#0088ff", "#c8e6d2", "#e6194b", "#f58231", "#ffe119", "#fabebe", "#aaffc3", "#bcf60c"];
var currColor = 0;
var soundOn = true;

// wählt das canvas element
var canvas = document.getElementById("pong");

// getContext of canvas = Methoden und Eigenschaften und zu "zeichnen" und viel mit dem Leinwand zu machen
var ctx = canvas.getContext('2d');

// let ist eine Variable und new erzeugt eine Instanz
let hit = new Audio();
let wall = new Audio();
let userScore = new Audio();
let comScore = new Audio();

//src werden die Töne aus ihrer Quelle gezogen
hit.src = "sounds/hit.mp3";
wall.src = "sounds/wall.mp3";
comScore.src = "sounds/comScore.mp3";
userScore.src = "sounds/userScore.mp3";

// Ball object
var ball = {
    x : canvas.width/2,
    y : canvas.height/2,
    radius : 10,
    velocityX : 5,
    velocityY : 5,
    speed : 7,
    color : colorColl[currColor]
}

// Variable User Paddle
var user = {
    x : 0, // left side of canvas
    y : (canvas.height - 100)/2, // -100 the height of paddle
    width : 10,
    height : 100,
    score : 0,
    color : colorColl[currColor]
}

//Variable COM Paddle
var com = {
    x : canvas.width - 10, // - width of paddle
    y : (canvas.height - 100)/2, // -100 the height of paddle
    width : 10,
    height : 100,
    score : 0,
    color : colorColl[currColor]
}

// Variable Netz
var net = {
    x : (canvas.width - 2)/2,
    y : 0,
    height : 10,
    width : 2,
    color : colorColl[currColor]
}

// drawRect =Rechtecke, die die Paddles zeichnen
function drawRect(x, y, w, h, color){
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

// draw circle = der Kreis wird gezeichnet
function drawArc(x, y, r, color){
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x,y,r,0,Math.PI*2,true);
    ctx.closePath();
    ctx.fill();
}

// hört auf die Mausbewegungen
canvas.addEventListener("mousemove", getMousePos);

function getMousePos(evt){
    let rect = canvas.getBoundingClientRect();

    user.y = evt.clientY - rect.top - user.height/2;
}

// wenn ein Punkt erzielt wird, dann wird der Ball resettet
function resetBall(){
    ball.x = canvas.width/2;
    ball.y = canvas.height/2;
    ball.velocityX = -ball.velocityX;
    ball.speed = 8;
	if(user.score==5 ){
		clearInterval(loop);
		alert('User Wins');
		user.score=0;
		com.score=0;
		document.getElementById("start").innerHTML="Start";
	}
	else if(com.score==5){
		clearInterval(loop);
		alert('Com Wins');
		user.score=0;
		com.score=0;
		document.getElementById("start").innerHTML="Start";
	}
}

// Netz wird gezeichnet
function drawNet(){
    for(let i = 0; i <= canvas.height; i+=15){
        drawRect(net.x, net.y + i, net.width, net.height, colorColl[currColor]);
    }
}

// ein Text wird gezeichnet
function drawText(text,x,y){
    ctx.fillStyle = colorColl[currColor];
    ctx.font = "75px fantasy";
    ctx.fillText(text, x, y);
}

// Kollisionserkennung
function collision(b,p){
    p.top = p.y;
    p.bottom = p.y + p.height;
    p.left = p.x;
    p.right = p.x + p.width;

    b.top = b.y - b.radius;
    b.bottom = b.y + b.radius;
    b.left = b.x - b.radius;
    b.right = b.x + b.radius;

    return p.left < b.right && p.top < b.bottom && p.right > b.left && p.bottom > b.top;
}

// update function, die Funktion, die alle Berechnungen durchführt
function update(){

    // Ändern Sie die Punktzahl der Spieler, wenn der Ball nach links geht "ball.x <0" Computer gewinnt, wenn "ball.x> canvas.width" der Benutzer gewinnt
    if( ball.x - ball.radius < 0 ){
        com.score++;
        if(soundOn) comScore.play();
        resetBall();
    }else if( ball.x + ball.radius > canvas.width){
        user.score++;
        if(soundOn) userScore.play();
        resetBall();
    }

    // Geschwindigkeit des Balls
    ball.x += ball.velocityX;
    ball.y += ball.velocityY;

    // computer spielt für sich selst, wir müssen gegen den Computer gewinnen
    // einfache künstliche Intelligenz
    com.y += ((ball.y - (com.y + com.height/2)))* randomMove();

    // Wenn der Ball mit der unteren und oberen Wand kollidiert, wechseln wir in die y-Geschwindigkeit um.
    
    if(ball.y - ball.radius < 0 || ball.y + ball.radius > canvas.height){
        ball.velocityY = -ball.velocityY;
        if(soundOn) wall.play();
    }

    // wir prüfen, ob das paddel den benutzer oder das com paddel getroffen hat
    let player = (ball.x + ball.radius < canvas.width/2) ? user : com;

    // wenn der ball das paddle berührt
    if(collision(ball,player)){
        // soll ein Ton abgespielt werden
        if(soundOn) hit.play();
        //wir überprüfen wo der ball auf das paddle trifft
        let collidePoint = (ball.y - (player.y + player.height/2));
       // normalisiere den Wert von collidePoint (Berührungspunkt), wir müssen Zahlen zwischen -1 und 1 bekommen.
        // -player.height/2 <Berührungspunkt <player.height/2
        collidePoint = collidePoint / (player.height/2);

       // Wenn der Ball die Spitze eines Paddels trifft, soll der Ball einen Winkel von -45 Grad einnehmen
        // Wenn der Ball die Mitte des Paddels trifft, soll der Ball einen Winkel von 0 Grad einnehmen
        // Wenn der Ball den Boden des Paddels berührt, soll der Ball 45 Grad haben
        // Math.PI / 4 = 45 Grad
        let angleRad = (Math.PI/4) * collidePoint;

        // Änderung der X- und Y-Geschwindigkeitsrichtung
        let direction = (ball.x + ball.radius < canvas.width/2) ? 1 : -1;
        ball.velocityX = direction * ball.speed * Math.cos(angleRad);
        ball.velocityY = ball.speed * Math.sin(angleRad);

        // Beschleunigung des Balls, wenn ein Paddel ihn schlägt.
        ball.speed += 0.1;
    }
}

// Render-Funktion, die Funktion, die alle Zeichnungen ausführt
function render(){

    // lösch den canvas canvas
    drawRect(0, 0, canvas.width, canvas.height, "#000");

    // erzeuge die User Punktezahl links
    drawText(user.score,canvas.width/4,canvas.height/5);

    // erzeuge den COM Punktezahl rechts
    drawText(com.score,3*canvas.width/4,canvas.height/5);

    // erzeuge ein Netz
    drawNet();

    // erzeuge user's paddle
    drawRect(user.x, user.y, user.width, user.height, colorColl[currColor]);

    // erzeuge COM's paddle
    drawRect(com.x, com.y, com.width, com.height, colorColl[currColor]);

    //erzeuge den Ball
    drawArc(ball.x, ball.y, ball.radius, colorColl[currColor]);
}
function game(){
    update();
    render();
}
// Bildfrequenz pro Sekunde
let framePerSecond = 50;

let loop ;
//ruft die Spielfunktion 50-mal alle 1 Sek. auf
function start(){
	var text=document.getElementById("start");

	if(text.innerHTML=='Start'){
		loop = setInterval(game,1000/framePerSecond);
		text.innerHTML="Stop";
	}
	else{
		clearInterval(loop);
		text.innerHTML="Start";
	}
}
//Funktion um die Farbe zu ändern
function changeColor() {
	currColor += 1;
	if(colorColl.length == currColor) currColor = 0;
}
//Funktion  um den Sound an und auszumachen
function changeSound() {
    if(soundOn) {
        soundOn = false;
    } else {
        soundOn = true;
    }
}
//Funktion um das Spiel neu zu starten oder zu stoppen
function newGame() {
	clearInterval(loop);
	loop = setInterval(game,1000/framePerSecond);
	document.getElementById("start").innerHTML="Stop"

    user.score = 0;
    com.score = 0;
    resetBall();

}
//Funktion, die die Schwierigkeiten definiert
function randomMove() {
    var mode = document.getElementById("mode").innerHTML;
    switch (mode) {
        case "Easy":
            return Math.random()*0.08;
        case "Normal":
            return Math.random()*0.09;
        case "Hard":
            return Math.random()*0.1;
        case "Godlike":
            return 0.1;
    }
}
//Funktion, die den Modus an Leiste anzeigen soll
function changeMode() {
    var mode = document.getElementById("mode");
    switch(mode.innerHTML) {
        case "Easy":
            mode.innerHTML = "Normal";
            return;
        case "Normal":
            mode.innerHTML = "Hard";
            return;
        case "Hard":
            mode.innerHTML = "Godlike";
            return;
        case "Godlike":
            mode.innerHTML = "Easy";
            return;
    }

}